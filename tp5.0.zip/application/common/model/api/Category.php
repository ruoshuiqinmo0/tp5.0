<?php

namespace app\common\model\api;

use think\Model;

class Category extends Model
{
    //
}
