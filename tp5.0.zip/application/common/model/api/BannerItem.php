<?php

namespace app\common\model\api;

use think\Model;

class BannerItem extends Model
{
    //
}
