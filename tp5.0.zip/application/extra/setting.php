<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/20
 * Time: 10:40
 */

return [
   'img_prefix'=>'htttp://m.legstem.com/image',
];