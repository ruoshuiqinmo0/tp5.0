<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:91:"D:\myphp_www\PHPTutorial\WWW\tp5.0\public/../application/index\view\file_upload\upload.html";i:1530260116;s:69:"D:\myphp_www\PHPTutorial\WWW\tp5.0\application\index\view\layout.html";i:1530182906;s:75:"D:\myphp_www\PHPTutorial\WWW\tp5.0\application\index\view\index\header.html";i:1530182445;s:75:"D:\myphp_www\PHPTutorial\WWW\tp5.0\application\index\view\index\footer.html";i:1530182365;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>[title]</title>
    <style>
        body{
            color: #333;
            font: 16px Verdana, "Helvetica Neue", helvetica, Arial, 'Microsoft YaHei', sans-ser
            if;
            margin: 0px;
            padding: 20px;
        }
        a{
            color: #868686;
            cursor: pointer;
        }
        a:hover{
            text-decoration: underline;
        }
        h2{
            color: #4288ce;
            font-weight: 400;
            padding: 6px 0;
            margin: 6px 0 0;
            font-size: 28px;
            border-bottom: 1px solid #eee;
        }
        div{
            margin:8px;
        }
        .info{
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }
        .copyright{
            margin-top: 24px;
            padding: 12px 0;
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>文件上传示例</title>
    <style>
        body {
            font-family:"Microsoft Yahei","Helvetica Neue",Helvetica,Arial,sans-serif;
            font-size:16px;
            padding:5px;
        }
        .form{
            padding: 15px;
            font-size: 16px;
        }
        .form .text {
            padding: 3px;
            margin:2px 10px;
            width: 240px;
            height: 24px;
            line-height: 28px;
            border: 1px solid #D4D4D4;
        }
        .form .btn{
            margin:6px;
            padding: 6px;
            width: 120px;
            font-size: 16px;
            border: 1px solid #D4D4D4;
            cursor: pointer;
            background:#eee;
        }
        .form .file{
            margin:6px;
            padding: 6px;
            width: 220px;
            font-size: 16px;
            border: 1px solid #D4D4D4;
            cursor: pointer;
            background:#eee;
        }
        a{
            color: #868686;
            cursor: pointer;
        }
        a:hover{
            text-decoration: underline;
        }
        h2{
            color: #4288ce;
            font-weight: 400;
            padding: 6px 0;
            margin: 6px 0 0;
            font-size: 28px;
            border-bottom: 1px solid #eee;
        }
        div{
            margin:8px;
        }
        .info{
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }
        .copyright{
            margin-top: 24px;
            padding: 12px 0;
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>
<h2>文件上传示例</h2>
<FORM method="post" enctype="multipart/form-data" class="form" action="<?php echo url('up'); ?>">
    选择文件：<INPUT type="file" class="file" name="file"><br/>
    <INPUT type="submit" class="btn" value=" 提交 ">
</FORM>
<div class="copyright">
    <a title="官方网站" href="http://www.thinkphp.cn">ThinkPHP</a>
    <span>V5</span>
    <span>{ 十年磨一剑-为API开发设计的高性能框架 }</span>
</div>
</body>
</html>
<div class="copyright">
    <a title="官方网站" href="http://www.thinkphp.cn">ThinkPHP</a>
    <span>V5</span>
    <span>{ 十年磨一剑-为API开发设计的高性能框架 }</span>
</div>
</body>
</html>