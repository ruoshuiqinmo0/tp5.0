<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"D:\myphp_www\PHPTutorial\WWW\tp5.0\public/../application/index\view\index\index.html";i:1530183332;}*/ ?>

<h2>用户列表（<?php echo $list->total(); ?>）</h2>
<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
<div class="info">
	ID：<?php echo $user['id']; ?><br/>
	昵称：<?php echo $user['nickname']; ?><br/>
	邮箱：<?php echo $user['email']; ?><br/>
	生日：<?php echo $user['birthday']; ?><br/>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
<?php echo $list->render(); ?>

