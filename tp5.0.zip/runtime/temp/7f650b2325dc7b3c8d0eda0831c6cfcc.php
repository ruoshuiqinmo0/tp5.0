<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"D:\myphp_www\PHPTutorial\WWW\tp5.0\public/../application/index\view\index\hello.html";i:1529996728;}*/ ?>
<html>
<head>
	
</head>
	<?php echo $result['id']; ?>---<?php echo $result['data']; ?>
</html>